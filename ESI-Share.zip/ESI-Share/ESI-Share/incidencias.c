

#include <stdio.h>


int main()
{
    int l_Incidencias =1 ; // la cantidad de filas de la matriz, modificable. Es uno por ahora
    
    
    typedef struct {
        
        
        int id_viaje[6];
        
        int id_usuario; //el usuario CULPABLE
        
        int id_registra; //el usuario que registra el incidente
        
        char* definicion[100];
        
        int estado; // Abierto, valido, cerrado
        
        
      
        
    }incidencias ; //Esto es una fila de la matriz 
    
    incidencias* m_incidencias = malloc(sizeof(incidencias)*l_incidencias);


    return 0;
}



int menu_inciusu(){
 int resp=0;
 do{
    printf("1. Crear incidencia \n");
    printf("2. Consultar incidencia \n");
    printf("Introduce un numero para elegir una opcion: \n");
    scanf("%i", &resp);
 }while(resp<1 || resp>2);

return 0;
}
int menu_inciadmin(){
 int resp=0;
 do{
    printf("1. Crear incidencia \n");
    printf("2. Eliminar incidencia \n");
    printf("3. Modificar incidencia \n");
    printf("4. Listar incidencias \n");
    printf("5. Validar incidencias \n");
    printf("6. Bloquear usuarios \n");
    printf("Introduce un numero para elegir una opcion: \n");
    scanf("%i", &resp);
 }while(resp<1 || resp>6);

return 0;
}

