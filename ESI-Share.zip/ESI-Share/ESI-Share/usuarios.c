#include <stdio.h>
#include<math.h>
#include<string.h>
#include<stdlib.h>

int resp;

void login();                   //Procedimiento que Mostrara pantalla de login y comprobara que existe.
int check_user(char *, char *); //Funcion que comprobara si el usuario existe y devolvera entero.
int mostrar();                  //Funcion que mostrara el menu de usuario, y devuelve entero con la elecci�n.
void modificar_usuario(usuarios *,int,int,usuarios);


void login(){                   //Funcion que comprueba en usuarios.txt usuario y contrase�a
char user[15];
char password[15];
do{
    puts("Introduce usuario");
    scanf("%s",&user);
    puts("Introduce contrase�a");
    scanf("%s",&password);
}while(check_user(user,password)!=0); //Corregir numero que devuelve check_user

}


int mostrar_menu_admin(){
    do{
        puts("1. Crear");
        puts("2. Buscar");
        puts("3. Comprobar");
        puts("4. ");
        scanf("%i",&resp);
    } while (resp<=0 && resp>=5);

    return resp;
}

void modificar_usuario(usuarios *m_usuarios,int lon,int indice,usuarios modif)
{
    m_usuarios[indice]=modif;
}
